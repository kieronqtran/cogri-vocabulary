export interface SendEmailSubscriptionData {
	template: string;
	context: object;
	to: string;
	subject: string;
}
