export interface SignUpForm {
  password: string;
  email: string;
  name: string;
}

export interface FormState {
  signUp: SignUpForm;
}
