import * as WordApiActions from './word-api.actions';
import * as WordPageActions from './word-page.actions';

export { WordApiActions, WordPageActions };
