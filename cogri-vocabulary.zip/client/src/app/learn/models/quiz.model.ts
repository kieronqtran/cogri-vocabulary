export interface MultipleChoice {
  wordId: number;
  title: string;
  correctAnswer: string;
  choices: string[];
}
