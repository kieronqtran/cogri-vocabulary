module.exports = {
    "extends": "google",
    "parserOptions": {
    	"ecmaVersion": 2017,
    }
};
